<?php
$host="localhost";
$user="root";
$password="";
$dbname="employee_pay_scenario";
$connection=mysqli_connect($host,$user,$password,$dbname);
if($connection)
{

  //echo "connectied";
}



 ?>
